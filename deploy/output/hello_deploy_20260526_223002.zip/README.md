# hello � AION App

Built with [AION Programming Language](https://github.com/kinghenesey/AION)

## Running Locally

```bash
pip install -r requirements.txt
python main.py hello.aion
```

## Environment Variables

Create a `.env` file with:

## Deploying

See `deploy_instructions.txt` for cloud deployment options.
