<div align="center">

# AION Programming Language

### The AI-Native Programming Language

![Version](https://img.shields.io/badge/version-1.1.1-00d4ff)
![PyPI](https://img.shields.io/pypi/v/aion-lang)
![Python](https://img.shields.io/badge/python-3.11+-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Tests](https://img.shields.io/badge/tests-147%20passing-success)

*"The first programming language where AI is syntax, not a library."*

[Install](#installation) · [Features](#features) · [Examples](#examples) · [Community](#community) · [Docs](#cli-commands)

</div>

---

## What is AION?

AION is an **AI-native programming language** built with Python. It's the first language where `think` is syntax — AI isn't a library you import, it's part of the language itself.

```aion
# AI is just syntax
think "What should I build today?"

# Chain AI agents with ->
"Nigerian fintech trends" -> researcher -> analyst -> writer

# Neural pipeline
pipeline market_analysis:
    collect "African tech ecosystem"
    process with ai
    generate report
    save to database

run pipeline market_analysis
```

---

## Installation

### Option 1 — pip (recommended)

```bash
pip install aion-lang
```

Add your API key to a `.env` file:
GEMINI_API_KEY=your_key_here

Get a free key at [ai.google.dev](https://ai.google.dev)

Run your first program:
```bash
aion hello.aion
```

### Option 2 — Clone from GitHub

```bash
git clone https://github.com/kinghenesey/AION.git
cd AION
pip install -r requirements.txt
```

Run a program:
```bash
python main.py examples/hello.aion
```

---

## Features

| Feature | Syntax | Description |
|---------|--------|-------------|
| 🧠 **Think** | `think "prompt"` | Call AI directly — no imports needed |
| 🔗 **Pipelines** | `researcher -> writer` | Chain AI agents with `->` |
| 🔀 **Model Routing** | `model "gemini"` | Switch AI providers at runtime |
| 👁️ **Vision** | `vision_scan("img.png")` | Analyze images with Gemini |
| 🎙️ **Voice** | `voice_speak("Hello!")` | Text-to-speech built in |
| ⚡ **Parallel** | `autonomous parallel:` | Run AI tasks simultaneously |
| 💾 **Memory** | `memory profile:` | Persistent data between runs |
| 🔒 **Sandbox** | `sandbox strict:` | Secure execution environment |
| 🧬 **Neural Pipeline** | `pipeline name:` | Full AI workflow in one block |
| 🏗️ **Compiler** | `aion compile app.aion` | Compile to standalone Python |
| ☁️ **Deploy** | `aion deploy cloud app.aion` | Deploy to cloud with one command |
| 🌐 **Web** | `use web` | Build real HTTP servers |
| 🗄️ **Database** | `use database` | Full SQLite CRUD |
| 🎨 **UI** | `use ui` | Generate HTML apps |

---

## Examples

### Hello World
```aion
name = "Emmanuel"
show "Hello {name}!"
show "Welcome to AION — where AI is syntax."
```

### Think (AI as syntax)
```aion
# Standalone think
think "What is the capital of Nigeria?"

# Captured think
idea = think "Give me one startup idea in one sentence"
show "AI said: {idea}"

# Think with variables
topic = "African fintech"
result = think "Analyze {topic} in 2025"
show result
```

### Agent Pipeline
```aion
# Chain agents — output flows left to right
"Analyze Nigerian tech ecosystem" -> researcher -> marketer -> reporter

# Captured result
report = "Future of AI in Africa" -> analyst -> writer
show report
```

### Neural Pipeline
```aion
pipeline market_research:
    collect "Nigerian startup ecosystem 2025"
    process with ai
    generate report
    save to database

run pipeline market_research
result = run pipeline market_research
show result
```

### Parallel Execution
```aion
# All three run simultaneously
autonomous parallel:
    think "Capital of Nigeria?"
    think "Capital of Ghana?"
    think "Capital of Kenya?"

# Captured results
results = autonomous parallel:
    think "Name one African unicorn"
    think "Name one Nigerian founder"
```

### Vision + Voice
```aion
use vision
use voice

# Analyze an image
description = vision_scan("photo.png")
show "AI sees: {description}"

# Speak the result
voice_speak("Analysis complete!")

# Listen for input
transcript = voice_listen()
show "You said: {transcript}"
```

### Persistent Memory
```aion
memory user_profile:
    name = "Emmanuel"
    language = "AION"
    run_count = 0

show user_profile["name"]
show user_profile["language"]
```

### Sandbox
```aion
sandbox strict:
    show "Running in secure mode"
    think "What is 2 + 2?"

sandbox relaxed:
    use files
    data = read_file("input.txt")
    show data
```

### Model Routing
```aion
model "gemini"
think "Using Gemini now"

model "mock"
think "Using mock provider"
```

### Variables, Loops & Tasks
```aion
# Variables
name = "Emmanuel"
age  = 20
items = [1, 2, 3]

# Conditions
if age >= 18:
    show "Adult"
else:
    show "Minor"

# Loops
repeat 5:
    show "AION!"

for item in items:
    show item

# Tasks (functions)
task greet(name):
    show "Hello {name}!"
    return "Done"

result = greet("World")
show result
```

### Standard Library
```aion
use math
use text
use database
use web

show sqrt(144)
show upper("hello aion")

db_connect("myapp.db")
db_create("users", "name text, age integer")
db_insert("users", "Emmanuel, 20")
results = db_find("users", "all")
show results
```

---

## CLI Commands

```bash
# Run files
aion hello.aion
aion app.aion --debug

# Using python directly
python main.py hello.aion
python main.py repl
python main.py ide

# Developer tools
aion repl                    # Interactive shell
aion ide                     # Web IDE at localhost:3000
aion compile app.aion        # Compile to Python
aion deploy cloud app.aion   # Deploy to cloud
aion --version               # Show version
aion --help                  # Show help

# Package manager
python main.py --install charts
python main.py --packages
python main.py marketplace
```

---

## Standard Library

| Module | Key Functions |
|--------|--------------|
| `use math` | sqrt, floor, ceil, abs, pi |
| `use text` | upper, lower, trim, replace, split |
| `use files` | read_file, write_file, file_exists |
| `use datetime` | today, now, year, month, day |
| `use ai` | ai_ask, ai_summarize, ai_generate |
| `use vision` | vision_scan, vision_compare |
| `use voice` | voice_speak, voice_listen, voice_save |
| `use agents` | agent_create, agent_run |
| `use web` | web_app, web_route, web_start |
| `use database` | db_connect, db_create, db_insert, db_find |
| `use ui` | ui_app, ui_page, ui_title, ui_button |

---

## Project Structure
aion/
├── main.py              ← Entry point
├── runner.py            ← Pipeline orchestrator
├── config.py            ← Version & constants
├── repl.py              ← Interactive shell
├── aion_cli.py          ← pip CLI entry point
├── lexer/               ← Tokenizer
├── parser/              ← AST builder
├── interpreter/         ← Execution engine
├── compiler/            ← Bytecode compiler + VM
├── stdlib/              ← Standard library
├── ai/                  ← AI runtime + agents
├── web/                 ← Web framework
├── database/            ← Database system
├── ui/                  ← UI framework
├── web_ide/             ← Browser-based IDE
├── deploy/              ← Deployment tools
├── examples/            ← Example programs
└── tests/               ← Test suite (147 tests)

---

## Community

**AION Connect** — Share your AION projects with the community.

- Browse projects built with AION
- Share your own programs
- World chat with other developers
- Run projects live in the browser

---

## Roadmap

- [x] Core language (lexer, parser, interpreter)
- [x] Standard library (math, text, files, datetime)
- [x] AI runtime (Gemini, Claude, Mock)
- [x] `think` keyword — AI as syntax
- [x] Agent pipelines (`->` operator)
- [x] Model routing (`model "gemini"`)
- [x] Multimodal (vision + voice)
- [x] Parallel execution (`autonomous parallel`)
- [x] Persistent memory blocks
- [x] Sandboxing (`sandbox strict/relaxed`)
- [x] Neural pipelines (`pipeline name:`)
- [x] LLVM compiler backend
- [x] Cloud deployment
- [x] Web IDE
- [x] VS Code extension
- [x] PyPI package
- [x] AION Connect community
- [ ] LLVM native compilation
- [ ] Language server (LSP)
- [ ] AION package registry

---

## Built By

**Emmanuel King Christopher** — Built from scratch with Python 3.11.

> *"I didn't just learn to code. I built the tools other people use to code."*

---

## License

MIT License — free to use, modify, and distribute.

---

<div align="center">

**Star ⭐ this repo if AION inspired you!**

[github.com/kinghenesey/AION](https://github.com/kinghenesey/AION) · [PyPI](https://pypi.org/project/aion-lang/) · [AION Connect](https://github.com/kinghenesey/AION)

</div>