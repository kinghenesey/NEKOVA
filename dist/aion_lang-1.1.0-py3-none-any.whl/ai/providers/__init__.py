# =============================================================
# AION AI Runtime — Provider Registry
# =============================================================
# Priority order:
#   1. Gemini  (if GEMINI_API_KEY is set)
#   2. Claude  (if ANTHROPIC_API_KEY is set)
#   3. Mock    (always available as fallback)

from ai.providers.mock      import MockProvider
from ai.providers.anthropic import AnthropicProvider
from ai.providers.gemini    import GeminiProvider


PROVIDERS = [
    GeminiProvider,
    AnthropicProvider,
    MockProvider,
]

# Holds the user-selected provider name (set via `model "..."`)
# None means auto-detect from available API keys
_active_provider = None


def get_provider():
    """
    Return the active AI provider.
    If the user has called `model "..."`, use that.
    Otherwise auto-detect from available API keys:
      Gemini → Claude → Mock
    """
    global _active_provider

    if _active_provider is not None:
        return get_provider_by_name(_active_provider)

    for ProviderClass in PROVIDERS:
        provider = ProviderClass()
        if provider.is_available:
            return provider

    return MockProvider()


def set_provider(name: str):
    """
    Set the active provider by name.
    Called by the `model` keyword in AION programs.
    Raises ValueError if the name is not recognized.
    """
    global _active_provider

    providers = {
        "mock":     MockProvider,
        "claude":   AnthropicProvider,
        "anthropic": AnthropicProvider,
        "gemini":   GeminiProvider,
    }

    if name not in providers:
        available = ", ".join(providers.keys())
        raise ValueError(
            f"Unknown provider '{name}'.\n"
            f"  Available providers: {available}"
        )

    # Validate the provider is actually available
    provider = providers[name]()
    if not provider.is_available and name != "mock":
        raise ValueError(
            f"Provider '{name}' is not available.\n"
            f"  Make sure the API key is set in your .env file."
        )

    _active_provider = name


def get_provider_by_name(name: str):
    """Get a specific provider by name."""
    providers = {
        "mock":      MockProvider,
        "claude":    AnthropicProvider,
        "anthropic": AnthropicProvider,
        "gemini":    GeminiProvider,
    }

    if name not in providers:
        available = ", ".join(providers.keys())
        raise ValueError(
            f"Unknown provider '{name}'.\n"
            f"  Available providers: {available}"
        )

    return providers[name]()


def reset_provider():
    """
    Reset to auto-detection mode.
    Useful for testing or after a program finishes.
    """
    global _active_provider
    _active_provider = None